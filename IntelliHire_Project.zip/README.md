# IntelliHire

AI-powered job screening and candidate shortlisting system.
