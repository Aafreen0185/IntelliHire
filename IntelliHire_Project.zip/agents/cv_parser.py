# cv_parser.py - placeholder

"""Module for cv parser"""