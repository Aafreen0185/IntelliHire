# jd_summarizer.py - placeholder

"""Module for jd summarizer"""