# shortlister.py - placeholder

"""Module for shortlister"""